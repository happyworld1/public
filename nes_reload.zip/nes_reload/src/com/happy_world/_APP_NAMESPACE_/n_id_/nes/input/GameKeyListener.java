package com.happy_world._APP_NAMESPACE_.n_id_.nes.input;

public interface GameKeyListener {
	void onGameKeyChanged();
}
