#ifndef EMUTICKS_H
#define EMUTICKS_H

#ifdef __cplusplus
extern "C" {
#endif

void ticksInitialize();
unsigned int ticksGetTicks();

#ifdef __cplusplus
}
#endif
#endif

