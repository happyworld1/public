
void readpng(unsigned short *dest, const char *fname);

