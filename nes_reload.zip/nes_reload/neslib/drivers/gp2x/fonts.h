
extern unsigned char fontdata8x8[64*16];
extern unsigned char fontdata6x8[256-32][8];

