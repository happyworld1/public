#ifndef __MMUHACK__
#define __MMUHACK__

extern int mmuhack(void);
extern int mmuunhack(void);

#endif /* __MMUHACK__ */
