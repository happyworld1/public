#ifdef NETWORK

#include "types.h"

int FCEUD_NetworkConnect(void)
{
	return 0;
}

int FCEUD_SendData(void *data, uint32 len)
{
	return 0;
}

int FCEUD_RecvData(void *data, uint32 len)
{
	return 0;
}

void FCEUD_NetworkClose(void)
{
}

void FCEUD_NetplayText(uint8 *text)
{
}

#endif
