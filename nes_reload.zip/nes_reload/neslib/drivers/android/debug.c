#define LOG_TAG "libnes"

void FCEUD_PrintError(char *s)
{
//	LOGE(s);
}

void FCEUD_Message(char *s)
{
//	LOGD(s);
}
