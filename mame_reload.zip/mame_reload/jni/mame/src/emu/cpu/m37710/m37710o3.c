#include "emu.h"
#include "debugger.h"
#include "m37710cm.h"
#define EXECUTION_MODE EXECUTION_MODE_M1X1
#include "m37710op.h"
