#pragma once

#ifndef __TMS32051_H__
#define __TMS32051_H__

DECLARE_LEGACY_CPU_DEVICE(TMS32051, tms32051);

CPU_DISASSEMBLE( tms32051 );

#endif /* __TMS32051_H__ */
