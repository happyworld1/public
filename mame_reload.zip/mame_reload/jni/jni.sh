#!/usr/bin/env bash
javah -classpath ../bin/classes com.seleuco.mame4droid.Emulator
