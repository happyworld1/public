#ifndef F3DWRUS_H
#define F3DWRUS_H

#define F3DWRUS_TRI2        0xB1
void F3DWRUS_Init();

#endif

