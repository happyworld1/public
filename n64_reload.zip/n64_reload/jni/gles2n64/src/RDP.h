#ifndef RDP_H
#define RDP_H

void RDP_Init();

#endif

