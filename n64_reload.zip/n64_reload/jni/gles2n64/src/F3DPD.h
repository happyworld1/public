#ifndef F3DPD_H
#define F3DPD_H

#define F3DPD_VTXCOLORBASE      0x07

void F3DPD_Init();
#endif

